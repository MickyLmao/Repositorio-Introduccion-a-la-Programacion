﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L8_MRV_1040822
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int num;
            num = int.Parse(textBox1.Text);
            int suma = 0;
            for (int i = 0; i <= num; i++)
            {
                suma = suma + i;
            }
            textBox2.Text = suma.ToString();
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {
            string multi = "";
            for (int i = 1; i <= 10; i++)
            {
                for (int x = 1; x <= 10; x++)
                {
                    if (x <= 9)
                    {
                        multi = multi + Convert.ToString(i * x) + "\t";
                    }
                    if (x == 10)
                    {
                        multi = multi + Convert.ToString(i * x) + "\n";
                    }
                }
                label2.Text = Convert.ToString(multi);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int pestaña = comboBox1.SelectedIndex;
            switch (pestaña)
            {
                case 0:
                    tabControl1.SelectedIndex = 0;
                    break;
                case 1:
                    tabControl1.SelectedIndex = 1;
                    break;
                case 2:
                    tabControl1.SelectedIndex = 2;
                    break;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int resultado = 0;
            int n1= int.Parse(textBox3.Text);

            for (int i = 1; i < n1; i++)
            {
                if (n1 % i == 0)
                {
                    resultado = resultado + i;
                }

            }


            if (resultado == n1)
            {
                label4.Text = "El número es perfecto";
            }
            else
            {
                label4.Text = "El número no es perfecto";
            }
        }
    }
}
