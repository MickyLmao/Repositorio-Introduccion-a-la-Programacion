﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RETO_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("lab10");
            Console.WriteLine("ingrese el cateto A");
            double catetoingresado = double.Parse(Console.ReadLine());
            Console.WriteLine("Iingrese angulo opuesto A en radianes");
            double angulopingresadoA = double.Parse(Console.ReadLine());
            
            double catetobcalculado = 0;
            double catetoccalculado = 0;
            

            triangulo objtcirculo = new triangulo(catetoingresado, angulopingresadoA);

            objtcirculo.Calculargeometria(ref catetobcalculado, ref catetoccalculado);

            Console.WriteLine("catetob " + catetobcalculado);
            Console.WriteLine("catetoc " + catetoccalculado);
       

            Console.ReadKey();

        }
    }
    class triangulo
    {
        private double catetoA, anguloA, altura, largo;
        public triangulo(double Bases, double AnguloA )
        {
            catetoA = Bases;
            anguloA = AnguloA;

        }

        private double obtenercatetoB()
        {
            double CatetoB = (catetoA) / (Math.Tan(anguloA));
            return CatetoB;

        }
        private double obtenercatetoC()
        {
            double CatetoC = ((catetoA) / Math.Sin(anguloA));
            return CatetoC;
        }
        public void Calculargeometria(ref double uncatetoB, ref double uncatetoC)
        {

            uncatetoB = obtenercatetoB();
            uncatetoC = obtenercatetoC();
            
        }


    }
}
