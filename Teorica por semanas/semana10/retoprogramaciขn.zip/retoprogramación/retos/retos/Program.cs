﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace retos
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int numero1, numero2, resultado, resultradocalculado, respuesta;
            Console.WriteLine("Ingrese un número Entero: ");
            numero1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese un número Entero: ");
            numero2 = int.Parse(Console.ReadLine());
           
            
            Console.WriteLine("ingrese el resultado de los dos numeros sumados");
            resultradocalculado = int.Parse(Console.ReadLine());

            resultado = numero1 + numero2;
            respuesta = numero1 + numero2;

            
                if (resultradocalculado == resultado)
                {

                    Console.WriteLine("el resultado es correcto");

                }
                else
                {

                  Console.WriteLine("la respuesta es incorrecta");
                  Console.WriteLine("INTENTE DE NUEVO");

                }

           
           

            Console.ReadKey();
            
            
        }
    }
}
