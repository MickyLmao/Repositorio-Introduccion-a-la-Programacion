﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace retoedificio
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] ninos;
            ninos = new int[5];

            int[] personas;
            personas = new int[5];
            int j = 1;
            int N = 1;
            int k = 1;

            for (int i = 0; i < 5; i++)
            {

                Console.WriteLine("Ingrese el numero de personas que viven en el nivel: " + j);
                personas[i] = int.Parse(Console.ReadLine());
                j++;
                Console.WriteLine("Ingrese el numero de niños que viven en el nivel: " + N);
                ninos[i] = int.Parse(Console.ReadLine());
                N++;

            }
            for (int i = 0; i < 5; i++)
            {

                Console.WriteLine("Numero de personas en el nivel " + k);
                Console.WriteLine(personas[i]);
                
                Console.WriteLine("Numero de ninos que viven en el nivel " + k);
                Console.WriteLine(ninos[i]);
                k++;
            }
            if (ninos[0] > ninos[1] && ninos[0] > ninos[2] && ninos[0] > ninos[3] && ninos[0] > ninos[4])
            {
                Console.WriteLine("El nivel con mas ninnos es el 1");
            }
            else
            {
                if (ninos[1] > ninos[0] && ninos[1] > ninos[2] && ninos[1] > ninos[3] && ninos[1] > ninos[4])
                {
                    Console.WriteLine("El nivel con mas ninnos es el 2");
                }
                else
                {
                    if (ninos[2] > ninos[0] && ninos[2] > ninos[1] && ninos[2] > ninos[3] && ninos[2] > ninos[4])
                    {
                        Console.WriteLine("El nivel con mas ninos es el 3");
                    }
                    else
                    {
                        if (ninos[3] > ninos[0] && ninos[3] > ninos[2] && ninos[3] > ninos[1] && ninos[3] > ninos[4])
                        {
                            Console.WriteLine("El nivel con mas ninnos es el 4");
                        }
                        else
                        {
                            if (ninos[4] > ninos[1] && ninos[4] > ninos[2] && ninos[4] > ninos[3] && ninos[4] > ninos[0])
                            {
                                Console.WriteLine("El nivel con mas ninos es el 5");
                            }
                            else
                            {
                                Console.WriteLine("Varios niveles cuentas con la mayor cantidad de ninos");
                            }
                        }
                    }
                }
            }
            Console.ReadKey();
        }
    }
}
