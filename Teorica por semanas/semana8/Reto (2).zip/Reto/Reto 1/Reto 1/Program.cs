﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reto_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int letra = 0;
            int x = 0, y = 0, z = 0, k = 0, O = 0, e = 0;
            Console.WriteLine("CLAVE: 1=a, 2=e, 3=i, 4=o, 5=u");
            Console.WriteLine("Escriba el número que representa la vocal que desea escribir");
            letra=int.Parse(Console.ReadLine());

            
            if (letra==1)
            {
                do
                {
                    
                    Console.Write("x");

                    x++;


                } while (x <= 9);
                do
                {

                    Console.WriteLine("x         x");

                    y++;


                } while (y <= 4);

                do
                {

                    Console.Write("x");

                    z++;


                } while (z <= 9);
                do
                {

                    Console.WriteLine("x         x");

                    k++;


                } while (k <= 6);
            }
            else
            {
                if(letra==2)
                {
                    do
                    {

                        Console.Write("x ");

                        e++;


                    } while (e <= 10);

                    do
                    {

                        Console.WriteLine("x");

                        e++;


                    } while (e <= 15);

                    do
                    {

                        Console.Write("x ");

                        e++;


                    } while (e <= 26);
                    do
                    {

                        Console.WriteLine("x");

                        e++;


                    } while (e <= 31);
                    do
                    {

                        Console.Write("x ");

                        e++;


                    } while (e <= 43);
                }
                else
                {
                    if (letra==3)
                    {
                        int i = 0;

                        do
                        {

                            Console.Write("x ");

                            i++;


                        } while (i <= 9);

                        do
                        {

                            Console.WriteLine("        x         ");

                            i++;


                        } while (i <= 17);
                        do
                        {

                            Console.Write("x ");

                            i++;


                        } while (i <= 27);

                    }
                    else
                    {
                        if (letra==4)
                        {
                            do
                            {

                                Console.Write("x");

                                k++;


                            } while (k <= 20);
                            do
                            {

                                Console.WriteLine("x             x");

                                k++;


                            } while (k <= 30);
                            do
                            {

                                Console.Write("x");

                                k++;


                            } while (k <= 45);
                        }
                        else
                        {
                            if (letra==5)
                            {
                                int u = 0;

                                do
                                {

                                    Console.WriteLine("x                     x");

                                    u++;


                                } while (u <= 11);

                                do
                                {

                                    Console.Write("x ");

                                    u++;


                                } while (u <= 23);
                            }
                            else
                            {
                                Console.WriteLine("la letra ingresada no es una vocal");
                            }
                        }
                    }
                }
            }
            Console.ReadKey();
        }
        

    }
}
