﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace retosprogra
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int x = 0, y = 0, z = 0, k = 0, O = 0 , e = 0;

            //letra A
            do
            {
             
               Console.Write("x");
               
               x++; 
               

            } while (x <= 9 );
            do
            {

                Console.WriteLine("x         x");

                y++;


            } while (y <= 4);

            do
            {

                Console.Write("x");

                z++;


            } while (z <= 9);
            do
            {

                Console.WriteLine("x         x");

                k++;


            } while (k <= 6);
            Console.WriteLine("");
            Console.WriteLine("");
            //letra O
            do
            {

                Console.Write("x");

                k++;


            } while (k <= 20);
            do
            {

                Console.WriteLine("x             x");

                k++;


            } while (k <= 30);
            do
            {

                Console.Write("x");

                k++;


            } while (k <= 45);
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            //letra e
            do
            {

                Console.Write("x ");

                e++;


            } while (e <= 10);

            do
            {

                Console.WriteLine("x");

                e++;


            } while (e <= 15);

            do
            {

                Console.Write("x ");

                e++;


            } while (e <= 26);
            do
            {

                Console.WriteLine("x");

                e++;


            } while (e <= 31);
            do
            {

                Console.Write("x ");

                e++;


            } while (e <= 43);

            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");

            //letra I
            
            int i = 0;

            do
            {

                Console.Write("x ");

                i++;


            } while (i <= 9);

            do
            {

                Console.WriteLine("        x         ");

                i++;


            } while (i <= 17);
            do
            {

                Console.Write("x ");

                i++;


            } while (i <= 27);

            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");

            //letra U

            int u = 0;
            
            do
            {

                Console.WriteLine("x                     x");

                u++;


            } while (u <= 11);

            do
            {

                Console.Write("x ");

                u++;


            } while (u <= 23);


            Console.ReadKey();
           

        }
    }
}
