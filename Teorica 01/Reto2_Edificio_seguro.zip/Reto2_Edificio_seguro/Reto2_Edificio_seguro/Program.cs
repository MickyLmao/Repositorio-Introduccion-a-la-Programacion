﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reto2_Edificio_seguro
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string []encargado;
            encargado = new string[5];
            int[] adultos; 
            adultos=new int[5];
            int[] ninos;
            ninos=new int[5];
            int j=1;
            int k = 1;
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Ingrese el número de adultos en el nivel: "+j);
                adultos[i] = int.Parse(Console.ReadLine());
                Console.WriteLine("Ingrese el número de niños en el nivel: " + j);
                ninos[i] = int.Parse(Console.ReadLine());
                Console.WriteLine("Ingrese el nombre del encargado del nivel: " + j);
                encargado[i] = Console.ReadLine();
                Console.WriteLine("");
                j++;
            }
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Número de adultos en el nivel "+k);
                Console.WriteLine(adultos[i]);
                Console.WriteLine("Número de niños en el nivel " + k);
                Console.WriteLine(ninos[i]);
                Console.WriteLine("El número total de personas en el nivel "+k+" es: "+(adultos[i]+ninos[i]));
                Console.WriteLine("Nombre del encargado del nivel " + k);
                Console.WriteLine(encargado[i]);
                Console.WriteLine("");
                k++;
            }
            if (adultos[0] + ninos[0] > adultos[1] + ninos[1]&& adultos[0] + ninos[0] > adultos[2] + ninos[2] && adultos[0] + ninos[0] > adultos[3] + ninos[3] && adultos[0] + ninos[0] > adultos[4] + ninos[4])
            {
                Console.WriteLine("El encargado del nivel con más personas es: " + encargado[0]);
            }
            else
            {
                if (adultos[1] + ninos[1] > adultos[0] + ninos[0] && adultos[1] + ninos[1] > adultos[2] + ninos[2] && adultos[1] + ninos[1] > adultos[3] + ninos[3] && adultos[1] + ninos[1] > adultos[4] + ninos[4])
                {
                    Console.WriteLine("El encargado del nivel con más personas es: " + encargado[1]);
                }
                else
                {
                    if (adultos[2] + ninos[2] > adultos[0] + ninos[0] && adultos[2] + ninos[2] > adultos[1] + ninos[1] && adultos[2] + ninos[2] > adultos[3] + ninos[3] && adultos[2] + ninos[2] > adultos[4] + ninos[4])
                    {
                        Console.WriteLine("El encargado del nivel con más personas es: " + encargado[2]);

                    }
                    else
                    {
                        if (adultos[3] + ninos[3] > adultos[0] + ninos[0] && adultos[3] + ninos[3] > adultos[1] + ninos[1] && adultos[3] + ninos[3] > adultos[2] + ninos[2] && adultos[3] + ninos[3] > adultos[4] + ninos[4])
                        {
                            Console.WriteLine("El encargado del nivel con más personas es: " + encargado[3]);
                        }
                        else
                        {
                            if (adultos[4] + ninos[4] > adultos[0] + ninos[0] && adultos[4] + ninos[4] > adultos[1] + ninos[1] && adultos[4] + ninos[4] > adultos[2] + ninos[2] && adultos[4] + ninos[4] > adultos[3] + ninos[3])
                            {
                                Console.WriteLine("El encargado del nivel con más personas es: " + encargado[4]);
                            }
                            else
                            {
                                Console.WriteLine("Varios niveles tienen la mayor cantidad de personas");
                            }
                        }
                    }
                }
                Console.ReadKey();
            }

        }
      
    }
}
