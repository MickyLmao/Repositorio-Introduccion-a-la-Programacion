﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reto1_edificio
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Sergio Montoya 1016622
            //Michael Rivas 1040822
            //Diego Arroyo 1143022
            int[] personas;
            personas = new int[5];
            int j=1;
            int k = 1;
      
            for (int i = 0; i < 5; i++) {
                 
            Console.WriteLine("Ingrese el numero de personas que viven en el nivel: " + j);
            personas[i] = int.Parse(Console.ReadLine());
                j++;   

            }
            for (int i = 0; i < 5; i++)
            {
                
                Console.WriteLine("Numero de personas en el nivel " + k);
                Console.WriteLine(personas[i]);
                
                k++;
            }
            if (personas[0] < personas[1]&& personas[0] < personas[2] && personas[0] < personas[3] && personas[0] < personas[4])
            {
                Console.WriteLine("El nivel con menos personas es el 1");
            }
            else
            {
                if (personas[1] < personas[0] && personas[1] < personas[2] && personas[1] < personas[3] && personas[1] < personas[4])
                {
                    Console.WriteLine("El nivel con menos personas es el 2");
                }
                else
                {
                    if (personas[2] < personas[0] && personas[2] < personas[1] && personas[2] < personas[3] && personas[2] < personas[4])
                    {
                        Console.WriteLine("El nivel con menos personas es el 3");
                    }
                    else
                    {
                        if (personas[3] < personas[0] && personas[3] < personas[2] && personas[3] < personas[1] && personas[3] < personas[4])
                        {
                            Console.WriteLine("El nivel con menos personas es el 4");
                        }
                        else
                        {
                            if (personas[4] < personas[1] && personas[4] < personas[2] && personas[4] < personas[3] && personas[4] < personas[0])
                            {
                                Console.WriteLine("El nivel con menos personas es el 5");
                            }
                            else
                            {
                                Console.WriteLine("Varios niveles cuentas con la menor cantidad de personas");
                            }
                        }
                    }
                }
            }
            Console.ReadKey();

        }
    }
}
